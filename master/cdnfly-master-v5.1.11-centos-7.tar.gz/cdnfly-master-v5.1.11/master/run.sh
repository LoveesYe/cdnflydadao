export FLASK_APP="/opt/cdnfly/master/route.py"
export FLASK_DEBUG=1
/opt/venv/bin/flask run -h 0.0.0.0 -p 88  --with-threads

